const form = document.getElementById('feedbackForm');

const list = document.getElementById('feedbackList');

form.addEventListener('submit', function(e) {

  e.preventDefault();

  const name = document.getElementById('name').value;

  const type = document.getElementById('type').value;

  const comment = document.getElementById('comment').value;

  const feedbackItem = document.createElement('div');

  feedbackItem.classList.add('feedback-item');

  feedbackItem.innerHTML = `

    <h4>${name}</h4>

    <span>Type: ${type}</span>

    <p>${comment}</p>

  `;

  list.appendChild(feedbackItem);

  form.reset();

  alert("✅ Thank you for your feedback!");

});